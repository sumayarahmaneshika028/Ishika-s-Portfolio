SUMAYA RAHMAN ESHIKA — PERSONAL PORTFOLIO

PROJECT FILES
- index.html: page structure and portfolio information
- style.css: black-and-gold design and responsive layout
- script.js: small mobile-navigation interaction
- images/profile-photo.jpeg: original profile photograph

HOW TO OPEN IN VISUAL STUDIO CODE
1. Extract this ZIP file.
2. Open Visual Studio Code.
3. Select File > Open Folder.
4. Choose the folder named Sumaya_Rahman_Eshika_Portfolio.
5. Open index.html. For a convenient live preview, use the Live Server extension, or open index.html in a browser.

IMPORTANT
Keep the images folder beside index.html. Do not move profile-photo.jpeg out of the images folder. The image path is relative, so it will work locally and after publishing the complete folder to GitHub.

GITHUB
Upload the complete project folder contents (index.html, style.css, script.js, images/, and README.txt) to one repository. Do not upload only the photo by itself.

The profile photograph is the original supplied image; only its display position/crop is controlled by CSS.
